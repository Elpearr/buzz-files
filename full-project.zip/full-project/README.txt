Thanks for downloading the demonstration program of "Buzz - Your Enterprise Trigger Word Deterrent".

Before you start, please read the following important information.

OPENING:

Run Command Prompt and cd to the folder, then run "python program.py"
> An easier way of opening is to look at the address bar at the top of File Explorer, clicking it to open a search bar and typing "cmd" - from where you can run "python program.py"
The address bar, for example, might look like this:

C:\Users\User1\Downloads\full-project
or
🖥️ > Downloads > full-project >

CLOSING:
When you are contempt with your testing, hit CTRL + C on your keyboard to properly stop the program.

EDITING:
The "lexiconsList.txt" is editable to detect whatever you may please.
This includes other languages; if you would like to use any other languages please download and appropriately name matching the included one in this program.

Link for additional models:
https://alphacephei.com/vosk/models

FILE GENERATION:
After properly closing, the program will save your audio stream to a timestamped .wav file, and a transcript will be saved as a timestamped .txt file.


TROUBLESHOOTING & DEPENDENCIES:
The program relies on Python to run. If Python and the rest of the dependencies are not installed, it is advised to do so or else the program will not run.
The notable dependencies that may not come preinstalled with Python are as follows:

- PyAudio
- Vosk
- Wave

To check if you have these dependencies, or if you are receiving errors regarding not having these installed, open Command Prompt and run:
"pip install [Insert dependency here"

For example, "pip install pyaudio". As I already have it installed, it will tell me so. If I didn't, it would promptly downloaded.



https://github.com/Elpearr/buzz-files


