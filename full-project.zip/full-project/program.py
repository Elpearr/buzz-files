import sys
import os
from vosk import Model, KaldiRecognizer
import pyaudio
import wave
import json
from datetime import datetime
import time

disabled = True

if (disabled != True):
    print("PREREQUISITES:")
    time.sleep(0.2)
    print("- You need a model from Vosk (https://alphacephei.com/vosk/models), make sure it is named 'model' and is in the same directory as this script.")
    time.sleep(0.2)
    print("- The script needs to be stopped by Keyboard Interruption in order to stop. Use CTRL + C to stop the script.")
    time.sleep(0.2)
    print("Additionally, you can stop this popup from showing by changing the 'disabled' variable on Line 10 to false.")
    time.sleep(0.5)
    carryon = input("Press enter to continue...")

# Load lexicons from a text file
def load_disallowed_words(file_path):
    try:
        with open(file_path, "r") as f:
            return [line.strip().lower().replace('"', '') for line in f if line.strip()]
    except FileNotFoundError:
        print(f"Error: Disallowed words file '{file_path}' not found.")
        sys.exit(1)

# Check if any lexicon matches in the text
def search_lexicons(text, lexicons):
    matches = []
    for lexicon in lexicons:
        if lexicon in text.lower():  # Case-insensitive match
            matches.append(lexicon)
    return matches

print("bootin' 'er up...")  # Debug

#Locate the model folder and lexicons list relative to the script's directory
script_dir = os.path.dirname(os.path.abspath(__file__))  # Directory of script
model_path = os.path.join(script_dir, "model")  # Look for 'model' folder
lexicon_file = os.path.join(script_dir, "lexiconsList.txt")  # Look for the lexicons list

# Check if the model folder exists
if not os.path.exists(model_path):
    print(f"Model folder not found in '{model_path}'! Please ensure the 'model' folder is in the same directory as this script. If you don't have a model, get one from: https://alphacephei.com/vosk/models")
    sys.exit(1)

# Check if the lexicon file exists
if not os.path.exists(lexicon_file):
    print(f"Lexicon file not found in '{lexicon_file}'! Please ensure 'lexiconsList.txt' is in the same directory as this script.")
    sys.exit(1)

try:
    print("Loading Vosk model...")  # Debug
    model = Model(model_path)
    recognizer = KaldiRecognizer(model, 16000)
    
    print("Initializing PyAudio...")  # Debug
    mic = pyaudio.PyAudio()
    
    # Generate unique filenames
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_filename = f"transcription_{timestamp}.txt"
    audio_filename = f"audio_{timestamp}.wav"
    print(f"Transcription log: {log_filename}")
    print(f"Audio file: {audio_filename}")

    # Open audio stream
    stream = mic.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=8000)
    stream.start_stream()
    print("Listening...")

    frames = []  # To store audio frames

    # Load lexicons from file
    lexicons = load_disallowed_words(lexicon_file)
    print(f"DEBUG: Loaded lexicons = {lexicons}")
    

    # Open log file outside of the loop
    with open(log_filename, "a") as log_file:
        while True:
            data = stream.read(4000, exception_on_overflow=False)
            frames.append(data)

            if len(data) == 0:
                continue

            # Process recognition
            if recognizer.AcceptWaveform(data):
                result = recognizer.Result()
                result_dict = json.loads(result)
                recognized_text = result_dict.get("text", "")
                if recognized_text:
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    print(f"[{timestamp}] Recognized: {recognized_text}")
                    log_file.write(f"[{timestamp}] {recognized_text}\n")
                    log_file.flush()

                    # Check for lexicon matches
                    matches = search_lexicons(recognized_text, lexicons)
                    if matches:
                        print(f"[{timestamp}] Matched Lexicons:")
                        for match in matches:
                            print(f"  - {match}")
                            log_file.write(f"  [MATCH] {match}\n")
                            log_file.flush()
                    else:
                        print(f"[{timestamp}] No lexicons matched.")
                        log_file.write(f"  [NO MATCH] No lexicons matched.\n")
                        log_file.flush()

            else:
                partial_result = recognizer.PartialResult()
                partial_dict = json.loads(partial_result)
                print("Partial:", partial_dict.get("partial", ""))

except KeyboardInterrupt:
    print("\nProcess stopped by Keyboard Interruption.")

except Exception as e:
    print(f"An error occurred: {e}")

finally:
    # Save the recorded audio to a WAV file
    try:
        stream.stop_stream()
        stream.close()
        mic.terminate()
        print("Audio stream and PyAudio terminated.")

        # Write audio data to a WAV file
        with wave.open(audio_filename, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(mic.get_sample_size(pyaudio.paInt16))
            wf.setframerate(16000)
            wf.writeframes(b"".join(frames))
        print(f"Saved audio to {audio_filename}")
        
    except Exception as e:
        print(f"Error occurred during audio file processing: {e}")